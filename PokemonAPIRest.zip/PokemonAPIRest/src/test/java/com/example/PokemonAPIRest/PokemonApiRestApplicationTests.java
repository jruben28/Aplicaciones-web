package com.example.PokemonAPIRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokemonApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
