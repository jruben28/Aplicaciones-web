package com.example.PokemonAPIRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokemonApiRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PokemonApiRestApplication.class, args);
	}

}
